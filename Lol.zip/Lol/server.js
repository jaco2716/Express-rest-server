import Express from "express";
import fs from "fs";
import path from "path";
import usercontroller from "./Controller/usercontroller.js"
const app = Express();
const port = 3001;

var users = [];



app.use(Express.json());
// app.use(Express.fs());
app.use(Express.urlencoded({ extended: true }));
app.use(Express.static('Model'));
app.use(Express.static('View'));
app.use(Express.static('Controller'));

app.get('/', function (req, res) {

  res.sendFile(path.join(path.resolve() + "/View/login.html"))
});


app.get("/users", (req, res) => {
  fs.readFile('./users.json', "utf8", (err, data) => {
    users = JSON.parse(data);
    res.json(users);
  });
});

app.get("/loggedInUser", (req, res) => {
  fs.readFile('./loggedInUser.json', "utf8", (err, data) => {
    var user = JSON.parse(data);
    res.json(user);
  });
});

app.get("/user/:id", (req, res) => {
  fs.readFile('./users.json', "utf8", (err, data) => {
    users = JSON.parse(data);
    res.json(users.find((user) => {
      return req.params.id == user.id;
    }));
  });
});

app.post("/createUser", (req, res) => {
  fs.readFile('./users.json', "utf8", (err, data) => {

    users = JSON.parse(data);
    req.body.id = users[users.length - 1].id + 1;
    users.push(req.body);
    var jsonData = JSON.stringify(users);
    fs.writeFile("users.json", jsonData, function (err) {
      if (err) {
        console.log(err);
      }
    });
    res.sendStatus(200);
  });
});

// app.get("/loginUser/:username", (req, res) => {
//   fs.readFile('./users.json', "utf8", (err, data) => {

//     users = JSON.parse(data);
//     var userlogin = users.findIndex((user) => user.username == +req.params.username)
//     console.log(userlogin)
//     if (userlogin > 0) {
//       alert("Value exists!")
//       res.json(userlogin);
//     }
//     else (err) => {
//       console.log(err);
//     }
//   });
// });

app.post("/userLogin", (req,res) =>{
  console.log('hej');
  users = JSON.parse(fs.readFileSync('users.json'));
  console.log(users)
  for(var i=0; i<users.length; i++){
    if(req.body.email == users[i].email && req.body.password == users[i].password){
      console.log("logget ind");
      var jsonData = JSON.stringify(users[i]);
      fs.writeFile("loggedInUser.json", jsonData, function (err) {
        if (err) {
          console.log(err);
        }
      });
      // res.json(users[i])
      usercontroller.userLogin(users[i], res)
      // userLogin(users[i], res);
    } else {
      console.log("failed login")
      res.json("fejl")

    }
  }
}

)




app.delete("/deleteUser/:id", (req, res) => {
  fs.readFile('./users.json', "utf8", (err, data) => {

    users = JSON.parse(data);
    var deleteindex = users.findIndex((user) => user.id == +req.params.id)
    console.log(deleteindex)
    if (deleteindex > 0) {
      users.splice(deleteindex, 1);
      var jsonData = JSON.stringify(users);
      fs.writeFile("users.json", jsonData, function (err) {
        if (err) {
          console.log(err);
        }
      });
      res.sendStatus(200);
    } else {
      res.sendStatus(400);
    }

  });
});

app.listen(port, () => console.log('Listening on port: ' + port));




// Input.onfocus = function() {
//   document.getElementById("message").style.display = "block";
// }

// Input.onkeyup = function() {

//   var lowerCaseLetters = /[a-z]/g;
//   if(Input.value.match(lowerCaseLetters)) {
//     letter.classList.remove("invalid");
//     letter.classList.add("valid");
//   } else {
//     letter.classList.remove("valid");
//     letter.classList.add("invalid");
// }

//   var upperCaseLetters = /[A-Z]/g;
//   if(Input.value.match(upperCaseLetters)) {
//     capital.classList.remove("invalid");
//     capital.classList.add("valid");
//   } else {
//     capital.classList.remove("valid");
//     capital.classList.add("invalid");
//   }

//   var numbers = /[0-9]/g;
//   if(Input.value.match(numbers)) {
//     number.classList.remove("invalid");
//     number.classList.add("valid");
//   } else {
//     number.classList.remove("valid");
//     number.classList.add("invalid");
//   }

//   if(Input.value.length >= 6) {
//     length.classList.remove("invalid");
//     length.classList.add("valid");
//   } else {
//     length.classList.remove("valid");
//     length.classList.add("invalid");
//   }
// }
