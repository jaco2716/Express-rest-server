// import usercontroller from "./usercontroller.js";
// import fs from "fs";

class User { 
    constructor(id, username, birthday, gender, email, password) {
    this.id = id;
    this.username = username;
    this.birthday = birthday;
    this.gender = gender;
    this.email = email;
    this.password = password;
    }
}


document.addEventListener("DOMContentLoaded", function() {

    var user;

    var nametext = document.getElementById("nametext");
    var agetext = document.getElementById("agetext");

   
    var slet = document.getElementById("DeleteProfile");
    slet.addEventListener("click", nametest)
    function nametest(){

        uploadUser();

    }
    nametext.innerHTML = "lort";
})


function uploadUser(user) {

    //Laver en fetch, see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
    fetch('http://localhost:3001/loggedInUser', {
        method: 'GET', // or 'PUT'

    }).then(response => response.json())
    .then(data => {
        user = data;
        console.log(data)
        nametext.innerHTML = data.username
    }).catch(error => {
        console.log("min error" + error)
    })
}